function X = non_uniform_noise_gen(M, t, ncov)
% Generate non-uniform noise
% Input:
% M - Number of array elements
% t - Noise length (number of samples)
% ncov - Noise power vector, length M
% Output:
% X - Noise matrix, size M x t
    

    if length(ncov) ~= M
        error('The length of ncov must equal the number of array elements M');
    end

    % Generate noise matrix
    X = gen_ccsg(M, t, ncov);
end

function X = gen_ccsg(m, n, cov)
    

    X0 = randn(m, n) + 1j * randn(m, n);
    if isscalar(cov)
        C = sqrt(cov)/sqrt(2); 
        X = C * X0;
    elseif isvector(cov)
        C = sqrt(cov(:))/sqrt(2);
        X = diag(C) * X0;
    else
        C = sqrtm(cov)/sqrt(2);
        X = C * X0;
    end
end
