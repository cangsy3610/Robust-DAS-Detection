clear;clc;close all;


%%  The code for paper:  Robust Detection of Underwater Target Against Nonuniform Noise With Optical Fiber DAS Array
%%%%  DOI: 10.1109/tim.2025.3643081
%%%%  IEEE link: https://ieeexplore.ieee.org/document/11298278
%%%%  Github: https://github.com/cangsy3610/Robust-DAS-Detection
%%  Author:  Cang Siyuan et al.
%%  Date: 2025.12.24
%%%%%  How to cite
%%%%  S. Cang et al., "Robust Detection of Underwater Target Against Nonuniform Noise With Optical Fiber DAS Array," 
%%%%   in IEEE Transactions on Instrumentation and Measurement, vol. 74, pp. 1-17, 2025, Art no. 6515517, doi: 10.1109/TIM.2025.3643081. 

%%%%%%%%%%%%%%%%%%%%%%%%%%   Start   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Parameter settings
fs=15000;       % Frequency Sample 
dt=1/fs;          % Time sampling interval
N=400;           % Snapshot
Ac=181 ;         % Coarse Grid
dAc=1;
t=0:dt:(N-1)*dt;          % Time Samples  
theta=-90:dAc:90;     % Coarse Grid
f=3000;                      % Center Frequency   
f1=3100;f2=3000;f3=3200;    % The frequency for each source
freq_true=[f1;f2;f3];
c=1500;                      %  Speed of sound in sea
lambda=c/f;               %  Wavelength of the sound wave
TrueTheta=[-2.36,11.78,25.88];                     % True incident angle of the signal      
K=length(TrueTheta);                 %  Number of sources         
M=12;                                        %  Number of array elements 
d=0.5*lambda;                           %% Array element spacing
R=(0:M-1)'*d;                             %% The vector for each array element spacing
%% Source Signal
Trans_sig_mtx=exp(1i*2*pi*freq_true*t);

%% Generate noise-type: Impulsive Noise
SNR_dB=0;  
alpha=1.2;
beta=0;
delta=0;
gamma=1;
noise_Impulsive=stblrnd(alpha,beta,gamma,delta,M,N);
power_noise=sum(abs(noise_Impulsive(1,:)).^2,2)/N;
Amp = sqrt(power_noise*10^(SNR_dB/10));   % Signal Amplitude

%%  Generate array received signal
Sig_Mtx=Amp*Trans_sig_mtx; 
Am_StrVec=zeros(M,K);
for mm=1:K
    Am_StrVec(:,mm)=exp(-1j*2*pi/lambda*R*sind(TrueTheta(mm)));
end
ReceivedArraySignal=Am_StrVec*Sig_Mtx+noise_Impulsive;  

%%  Design a general steering vector : W_strMtx
W_strMtx=zeros(M,Ac);
for m=1:M
    for ac=1:Ac
        W_strMtx(m,ac)=exp(-1j*2*pi/lambda*R(m,1)*sind(theta(ac)));
    end
end
%% SPICE
Iteration=200;                                %  Number of iterations
[~,p_Raw] = SPICE_OrigVersion(W_strMtx,ReceivedArraySignal,Iteration); % note here is not SPICE+, p is of length K+M
p_spice = real(p_Raw(1:Ac));
P_spice=10*log10(p_spice/max(p_spice));
%% q-SPICE
q = 1.5;                                %  Select optimal value for q in 【q-SPICE algorithm】
[p_q_spice,sigma]= q_SPICE_DOA(ReceivedArraySignal,W_strMtx,q,Iteration);  
P_q_spice=10*log10(p_q_spice/max(p_q_spice));

%% ----------- Find estimated theta --------------------%%%%%%%%%%%%%
[peaks_est,Idx_est]=findpeaks(P_q_spice);
[peaks_est_sort,II_est]=sort(peaks_est,'descend');
        
for ii=1:K
    Tagt_theta(ii)=theta(Idx_est(II_est(ii)));
end

Theta_est_q_spice=sort(Tagt_theta);
Theta_est_q_spice=Theta_est_q_spice(:)

%% q-SPICE-GNR
theta_coarse=Theta_est_q_spice;
theta_NER=3;                           % Neighborhood Expansion Range
intervals = [theta_coarse - theta_NER, theta_coarse + theta_NER];
intervals = sortrows(intervals,1);
% Merge overlapping intervals
merged = [];
if ~isempty(intervals)
    current = intervals(1,:);
    for i = 2:size(intervals,1)
        if intervals(i,1) <= current(2)  
            current(2) = max(current(2), intervals(i,2));
        else
            merged = [merged; current];
            current = intervals(i,:);
        end
    end
    merged = [merged; current];
end
% ------------------- Generate global fine grid------------------
FineStep=0.005;
theta_fine_all = [];
for i = 1:size(merged,1)
    seg = merged(i,1):FineStep:merged(i,2);
    theta_fine_all = [theta_fine_all, seg];
end
theta_fine_all = unique(theta_fine_all);  % Prevent duplicates due to floating-point errors
theta_fine_all = sort(theta_fine_all(:)');
% -------------------Design a new steering vector-------------------------
Ac_GNR=size(theta_fine_all,2);
W_strMtx_GNR=zeros(M,Ac_GNR);
for m=1:M
    for ac=1:Ac_GNR
        W_strMtx_GNR(m,ac)=exp(-1j*2*pi/lambda*R(m,1)*sind(theta_fine_all(ac)));
    end
end
[p_q_spice_GNR,~]= q_SPICE_DOA(ReceivedArraySignal,W_strMtx_GNR,q,Iteration);
P_q_spice_GNR=10*log10(p_q_spice_GNR/max(p_q_spice_GNR));

%----------- Find estimated theta -----------------------------------------
[peaks_est,Idx_est]=findpeaks(P_q_spice_GNR);
[peaks_est_sort,II_est]=sort(peaks_est,'descend');
        
for ii=1:K
    Tagt_theta_GNR(ii)=theta_fine_all(Idx_est(II_est(ii)));
end

Theta_est_q_spice_GNR=sort(Tagt_theta_GNR);
Theta_est_q_spice_GNR=Theta_est_q_spice_GNR(:)

%% Generate distinctive colors
color1=[122,41,30;250,200,205;219,49,244;54,195,201;0,70,222;84,134,135;124,187,0;189,30,30;158,148,182;]/255;
color2=[253,198,138;5,165,158;129,62,152;171,226,179;64,195,236;234,232,215;255,224,194;]/255;
%% Plot the spatial spectrum 
hFig=figure(1);  
plot(theta,P_spice,'-','Color',color2(2,:),'LineWidth',1.5); hold on;
plot(theta,P_q_spice,'-','Color',color2(5,:),'LineWidth',2.5); 
plot(theta_fine_all,P_q_spice_GNR,'-','Color','m','LineWidth',1.5)
plot(TrueTheta(1),0,'-p','Color','r','linewidth',2,'MarkerSize',8)
plot(TrueTheta(2),0,'-p','Color','r','linewidth',2,'MarkerSize',8)
plot(TrueTheta(3),0,'-p','Color','r','linewidth',2,'MarkerSize',8)
grid on;
title('Spatial Spectrum Estimates under Impulsive Noise')
xlabel('Angle/degree');
ylabel('Power of Signal/dB ');
set(gca,'linewidth',2,'fontsize',20,'fontname','Times New Roman');
legend('SPICE','q-SPICE','q-SPICE-GNR^2','true DOA','Location', 'southwest')
axis([-12,35,-50,0.5])
set(hFig, 'Position', [500, 300, 1350,900]);