function [p,sigma] = q_SPICE_DOA(y,B,q,iter_q)

%%  The code for paper:  Robust Detection of Underwater Target Against Nonuniform Noise With Optical Fiber DAS Array
%%%%  DOI: 10.1109/tim.2025.3643081
%%%%  IEEE link: https://ieeexplore.ieee.org/document/11298278
%%%%  Github: https://github.com/cangsy3610/Robust-DAS-Detection


% Input:
% y - Signal
% B - Dictionary (only signal part and not noise)
% q - Choice of norm
% -------------------------------------------------
% Output:
% p - Estimated p
% sigma - Estimated noise parameters
%%
r=1;

% Initializing
N = size(y,2); % Number of samples
K = size(B,2); % Number of candidates in the dictionary
M=size(B,1);
R_hat=y*y'/N;
inv_R_hat=pinv(R_hat);
I = eye(M);
A = [B I]; % Makeing the q_SPICE dictionary
%%
% Initial estimates of p and sigma
p=sum(abs(B'*y/M), 2 )/N;
sigma =ones(M,1);%abs(I'*y);
counter=0;
while counter<=iter_q
    pvec = [p;sigma];
    P = diag(pvec);
    % Estimating the covariance matrix
    R = A*P*A';
    inv_R=pinv(R);
    for ii=1:size(B,2)
        W(ii,1)=B(:,ii)'*inv_R_hat*B(:,ii)/N;
    end
    for ii=1:size(I,2)
        V(ii,1)=I(:,ii).'*inv_R_hat*I(:,ii)/N;
    end
    % Precalculating the inverse of R times the signal.
    invR_R_hat = inv_R*(sqrtm(R_hat));
    % beta for the non-zero valued elements in p
    for ii=1:K+M
        beta(ii,1) = pvec(ii)*norm(A(:,ii)'*invR_R_hat,2);
    end
    lambda_p=((W.^(r/(r+1))).'*beta(1:K).^(2*r/(r+1)))^((r+1)/2/r)+((V.^(q/(q+1))).'*beta(K+1:end).^(2*q/(q+1)))^((q+1)/2/q);
    % estimate p
    p =beta(1:K,1).^(2/(r+1))./W.^(r/(r+1))/lambda_p*((W.^(r/(r+1))).'*beta(1:K).^(2*r/(r+1)))^((r-1)/2/r) ;
    % estimate sigma
    sigma = beta(K+1:end,1).^(2/(q+1))./V.^(q/(q+1))/lambda_p*((V.^(q/(q+1))).'*beta(K+1:end,1).^(2*q/(q+1)))^((q-1)/2/q) ;
    % Take absolute value
    p=abs(p);
    sigma=abs(sigma);
    % completed another iteration
    counter = counter + 1;
end
% Total amount of iteration until convergence
% iterEnd = counter;
end